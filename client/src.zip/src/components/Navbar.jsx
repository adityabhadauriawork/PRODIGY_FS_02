import { Bell, Search, UserCircle2 } from "lucide-react";
import { motion } from "framer-motion";

export default function Navbar() {
  return (
    <motion.div
      initial={{ y: -25, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="
      flex
      justify-between
      items-center
      bg-slate-950/80
      backdrop-blur-xl
      border-b
      border-slate-800
      px-10
      py-6
      sticky
      top-0
      z-20
      "
    >
      <div className="relative w-[420px]">

        <Search
          className="
          absolute
          left-4
          top-1/2
          -translate-y-1/2
          text-slate-500
          "
          size={20}
        />

        <input
          placeholder="Search employee..."
          className="
          w-full
          rounded-xl
          bg-slate-900
          border
          border-slate-700
          py-3
          pl-12
          pr-4
          text-white
          outline-none
          focus:border-blue-500
          focus:shadow-[0_0_18px_rgba(59,130,246,.45)]
          transition-all
          "
        />

      </div>

      <div className="flex items-center gap-6">

        <motion.div
          whileHover={{ scale: 1.08 }}
          className="
          w-12
          h-12
          rounded-xl
          bg-slate-900
          flex
          items-center
          justify-center
          border
          border-slate-700
          cursor-pointer
          "
        >
          <Bell className="text-blue-400"/>
        </motion.div>

        <div className="flex items-center gap-3">

          <UserCircle2
            size={42}
            className="text-cyan-400"
          />

          <div>

            <h3 className="text-white font-semibold">

              Admin

            </h3>

            <p className="text-slate-400 text-sm">

              Administrator

            </p>

          </div>

        </div>

      </div>

    </motion.div>
  );
}