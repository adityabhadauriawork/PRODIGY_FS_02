import { Pencil, Trash2 } from "lucide-react";

const employees = [
  {
    id: "EMP001",
    name: "John Doe",
    department: "IT",
    position: "Frontend Developer",
    salary: "₹75,000",
    status: "Active",
  },
  {
    id: "EMP002",
    name: "Emily Watson",
    department: "HR",
    position: "HR Manager",
    salary: "₹65,000",
    status: "Active",
  },
  {
    id: "EMP003",
    name: "David Smith",
    department: "Finance",
    position: "Accountant",
    salary: "₹58,000",
    status: "Leave",
  },
];

export default function EmployeeTable() {
  return (
    <div className="rounded-3xl border border-slate-800 bg-slate-900 overflow-hidden shadow-[0_0_30px_rgba(37,99,235,.12)]">

      <div className="flex justify-between items-center px-8 py-6 border-b border-slate-800">

        <h2 className="text-white text-xl font-semibold">
          Employees
        </h2>

        <button className="px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white transition">
          Add Employee
        </button>

      </div>

      <table className="w-full text-left">

        <thead className="bg-slate-950 text-slate-300">

          <tr>

            <th className="px-8 py-5">ID</th>
            <th>Name</th>
            <th>Department</th>
            <th>Position</th>
            <th>Salary</th>
            <th>Status</th>
            <th className="text-center">Actions</th>

          </tr>

        </thead>

        <tbody>

          {employees.map((emp) => (

            <tr
              key={emp.id}
              className="border-b border-slate-800 hover:bg-slate-800/60 transition"
            >

              <td className="px-8 py-5 text-slate-300">

                {emp.id}

              </td>

              <td className="text-white font-medium">

                {emp.name}

              </td>

              <td className="text-slate-300">

                {emp.department}

              </td>

              <td className="text-slate-300">

                {emp.position}

              </td>

              <td className="text-green-400 font-semibold">

                {emp.salary}

              </td>

              <td>

                <span
                  className={`px-3 py-1 rounded-full text-sm ${
                    emp.status === "Active"
                      ? "bg-green-500/20 text-green-400"
                      : "bg-yellow-500/20 text-yellow-400"
                  }`}
                >
                  {emp.status}
                </span>

              </td>

              <td>

                <div className="flex justify-center gap-4">

                  <button className="text-blue-400 hover:text-blue-300">

                    <Pencil size={18} />

                  </button>

                  <button className="text-red-400 hover:text-red-300">

                    <Trash2 size={18} />

                  </button>

                </div>

              </td>

            </tr>

          ))}

        </tbody>

      </table>

    </div>
  );
}