import {
  LayoutDashboard,
  Users,
  UserPlus,
  BarChart3,
  Settings,
  LogOut,
  BriefcaseBusiness,
} from "lucide-react";

import { Link, useLocation } from "react-router-dom";
import { motion } from "framer-motion";

export default function Sidebar() {
  const location = useLocation();

  const menu = [
    {
      title: "Dashboard",
      icon: LayoutDashboard,
      path: "/dashboard",
    },
    {
      title: "Employees",
      icon: Users,
      path: "/dashboard",
    },
    {
      title: "Add Employee",
      icon: UserPlus,
      path: "/add-employee",
    },
    {
      title: "Analytics",
      icon: BarChart3,
      path: "/dashboard",
    },
    {
      title: "Settings",
      icon: Settings,
      path: "/dashboard",
    },
  ];

  return (
    <aside className="w-[270px] h-screen sticky top-0 bg-slate-950 border-r border-slate-800 flex flex-col justify-between">

      <div>

        <div className="p-8">

          <motion.div
            initial={{ scale: .8 }}
            animate={{ scale: 1 }}
            className="flex items-center gap-4"
          >

            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center shadow-[0_0_35px_rgba(59,130,246,.55)]">

              <BriefcaseBusiness size={28} className="text-white"/>

            </div>

            <div>

              <h2 className="text-white text-xl font-bold">

                Employee

              </h2>

              <p className="text-slate-400 text-sm">

                Management

              </p>

            </div>

          </motion.div>

        </div>

        <div className="px-5 mt-10 flex flex-col gap-3">

          {menu.map((item) => {

            const Icon = item.icon;

            const active = location.pathname === item.path;

            return (

              <Link key={item.title} to={item.path}>

                <motion.div

                  whileHover={{
                    x: 6,
                  }}

                  whileTap={{
                    scale: .97,
                  }}

                  className={`
                  flex
                  items-center
                  gap-4
                  rounded-2xl
                  px-5
                  py-4
                  transition-all
                  duration-300

                  ${
                    active
                      ? "bg-gradient-to-r from-blue-600 to-cyan-500 shadow-[0_0_30px_rgba(59,130,246,.55)]"
                      : "hover:bg-slate-900 text-slate-300"
                  }
                  `}
                >

                  <Icon size={22} />

                  <span className="font-medium">

                    {item.title}

                  </span>

                </motion.div>

              </Link>

            );
          })}

        </div>

      </div>

      <div className="p-5">

        <motion.button

          whileHover={{
            scale:1.03
          }}

          whileTap={{
            scale:.97
          }}

          className="
          w-full
          flex
          items-center
          justify-center
          gap-3
          rounded-2xl
          bg-red-500
          py-4
          font-semibold
          text-white
          hover:bg-red-600
          duration-300
          "

        >

          <LogOut size={20}/>

          Logout

        </motion.button>

      </div>

    </aside>
  );
}