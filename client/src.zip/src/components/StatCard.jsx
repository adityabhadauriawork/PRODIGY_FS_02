import { motion } from "framer-motion";

export default function StatCard({

title,

value,

icon,

color,

growth

}){

return(

<motion.div

whileHover={{
y:-8
}}

className="
relative
overflow-hidden
rounded-3xl
bg-slate-900
border
border-slate-800
p-7
shadow-[0_0_30px_rgba(37,99,235,.12)]
"

>

<div

className="
absolute
right-0
top-0
w-36
h-36
blur-3xl
opacity-30
"

style={{

background:color

}}

/>

<div className="flex justify-between items-center">

<div>

<p className="text-slate-400">

{title}

</p>

<h1
className="
text-white
text-4xl
font-bold
mt-2
"
>

{value}

</h1>

<p className="text-green-400 mt-4">

↑ {growth}

</p>

</div>

<div

className="
w-16
h-16
rounded-2xl
flex
items-center
justify-center
"

style={{

background:color

}}

>

{icon}

</div>

</div>

</motion.div>

)

}