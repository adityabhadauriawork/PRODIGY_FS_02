export default function AddEmployee() {
  return (
    <div className="p-10">
      <h1 className="text-4xl font-bold">
        Add Employee
      </h1>
    </div>
  );
}