import { useParams } from "react-router-dom";

export default function EditEmployee() {

  const { id } = useParams();

  return (
    <div className="p-10">
      <h1 className="text-4xl font-bold">
        Edit Employee {id}
      </h1>
    </div>
  );
}