import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import StatCard from "../components/StatCard";
import EmployeeTable from "../components/EmployeeTable";

import {
  Users,
  IndianRupee,
  Building2,
  UserCheck,
} from "lucide-react";

export default function Dashboard() {
  return (
    <div className="flex min-h-screen bg-[#020617]">

      <Sidebar />

      <div className="flex-1">

        <Navbar />

        <div className="p-10">

          <h1 className="text-4xl font-bold text-white mb-2">
            Dashboard
          </h1>

          <p className="text-slate-400 mb-10">
            Welcome back 👋 Here's today's overview.
          </p>

          <div className="grid grid-cols-4 gap-6">

            <StatCard
              title="Employees"
              value="124"
              growth="18%"
              color="#2563eb"
              icon={<Users className="text-white" />}
            />

            <StatCard
              title="Departments"
              value="08"
              growth="5%"
              color="#7c3aed"
              icon={<Building2 className="text-white" />}
            />

            <StatCard
              title="Monthly Salary"
              value="₹18.5L"
              growth="12%"
              color="#059669"
              icon={<IndianRupee className="text-white" />}
            />

            <StatCard
              title="Active"
              value="118"
              growth="3%"
              color="#ea580c"
              icon={<UserCheck className="text-white" />}
            />

          </div>

          <div className="mt-10">

            <EmployeeTable />

          </div>

        </div>

      </div>

    </div>
  );
}